﻿namespace DesignWorldcup
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.jogos = new System.Windows.Forms.Label();
            this.jogosa2 = new System.Windows.Forms.Label();
            this.jogosa3 = new System.Windows.Forms.Label();
            this.jogosa4 = new System.Windows.Forms.Label();
            this.jogosa5 = new System.Windows.Forms.Label();
            this.jogosa6 = new System.Windows.Forms.Label();
            this.jogosa1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // jogos
            // 
            this.jogos.BackColor = System.Drawing.Color.White;
            this.jogos.Font = new System.Drawing.Font("Arial Nova Cond", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jogos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.jogos.Location = new System.Drawing.Point(26, 114);
            this.jogos.Name = "jogos";
            this.jogos.Size = new System.Drawing.Size(369, 22);
            this.jogos.TabIndex = 34;
            this.jogos.Text = "     Jogos Realizados                        Data de Realização";
            // 
            // jogosa2
            // 
            this.jogosa2.BackColor = System.Drawing.Color.White;
            this.jogosa2.Font = new System.Drawing.Font("Arial Nova Cond", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jogosa2.Location = new System.Drawing.Point(26, 179);
            this.jogosa2.Name = "jogosa2";
            this.jogosa2.Size = new System.Drawing.Size(369, 22);
            this.jogosa2.TabIndex = 33;
            this.jogosa2.Text = "     Senegal: 2 - 20 :Holanda             Data: 02/03/1999";
            // 
            // jogosa3
            // 
            this.jogosa3.BackColor = System.Drawing.Color.White;
            this.jogosa3.Font = new System.Drawing.Font("Arial Nova Cond", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jogosa3.Location = new System.Drawing.Point(26, 214);
            this.jogosa3.Name = "jogosa3";
            this.jogosa3.Size = new System.Drawing.Size(369, 22);
            this.jogosa3.TabIndex = 32;
            this.jogosa3.Text = "     Qatar: 0 - 0 :Senegal                   Data: 04/12/2016";
            // 
            // jogosa4
            // 
            this.jogosa4.BackColor = System.Drawing.Color.White;
            this.jogosa4.Font = new System.Drawing.Font("Arial Nova Cond", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jogosa4.Location = new System.Drawing.Point(26, 247);
            this.jogosa4.Name = "jogosa4";
            this.jogosa4.Size = new System.Drawing.Size(369, 22);
            this.jogosa4.TabIndex = 31;
            this.jogosa4.Text = "     Holanda: 3 - 2 :Equador              Data: 32/13/2024";
            // 
            // jogosa5
            // 
            this.jogosa5.BackColor = System.Drawing.Color.White;
            this.jogosa5.Font = new System.Drawing.Font("Arial Nova Cond", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jogosa5.Location = new System.Drawing.Point(26, 283);
            this.jogosa5.Name = "jogosa5";
            this.jogosa5.Size = new System.Drawing.Size(369, 22);
            this.jogosa5.TabIndex = 30;
            this.jogosa5.Text = "     Qatar: 1 - 1 :Holanda                   Data: 22/22/3030";
            // 
            // jogosa6
            // 
            this.jogosa6.BackColor = System.Drawing.Color.White;
            this.jogosa6.Font = new System.Drawing.Font("Arial Nova Cond", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jogosa6.Location = new System.Drawing.Point(26, 315);
            this.jogosa6.Name = "jogosa6";
            this.jogosa6.Size = new System.Drawing.Size(369, 22);
            this.jogosa6.TabIndex = 29;
            this.jogosa6.Text = "     Senegal: 2 - 2 :Equador              Data: 01/01/0101";
            // 
            // jogosa1
            // 
            this.jogosa1.BackColor = System.Drawing.Color.White;
            this.jogosa1.Font = new System.Drawing.Font("Arial Nova Cond", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jogosa1.Location = new System.Drawing.Point(26, 146);
            this.jogosa1.Name = "jogosa1";
            this.jogosa1.Size = new System.Drawing.Size(369, 22);
            this.jogosa1.TabIndex = 28;
            this.jogosa1.Text = "     Qatar: 1 - 3 :Equador                   Data: 02/02/2020";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Medium", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(426, 114);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(362, 26);
            this.label2.TabIndex = 27;
            this.label2.Text = "Tabela de liderança";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(426, 146);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(362, 191);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Font = new System.Drawing.Font("Franklin Gothic Medium", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(12, 23);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 25);
            this.button1.TabIndex = 36;
            this.button1.Text = "VOLTAR";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button3.Font = new System.Drawing.Font("Franklin Gothic Medium", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(692, 23);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(85, 25);
            this.button3.TabIndex = 38;
            this.button3.Text = "GRUPO B";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.jogos);
            this.Controls.Add(this.jogosa2);
            this.Controls.Add(this.jogosa3);
            this.Controls.Add(this.jogosa4);
            this.Controls.Add(this.jogosa5);
            this.Controls.Add(this.jogosa6);
            this.Controls.Add(this.jogosa1);
            this.Controls.Add(this.label2);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label jogos;
        private System.Windows.Forms.Label jogosa2;
        private System.Windows.Forms.Label jogosa3;
        private System.Windows.Forms.Label jogosa4;
        private System.Windows.Forms.Label jogosa5;
        private System.Windows.Forms.Label jogosa6;
        private System.Windows.Forms.Label jogosa1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
    }
}